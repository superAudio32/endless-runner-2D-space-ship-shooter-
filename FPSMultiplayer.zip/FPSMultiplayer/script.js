const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// Game Variables
const playerSize = 50;
const enemySize = 40;
const bulletSize = 10;
const playerSpeed = 5;
const bulletSpeed = 10;
const enemySpeed = 2;
const maxEnemies = 20;
const maxBullets = 50;
const damageDistance = 20; // Distance within which enemies can damage the player

let player = {
    x: canvas.width / 4,
    y: canvas.height / 2,
    width: playerSize,
    height: playerSize,
    health: 3,
    maxHealth: 3,
    lives: 3,
    score: 0,
    kills: 0,
    level: 1,
    exp: 0,
    maxExp: 124,
    levelUpThresholds: [124, 190, 234, 322, 394, 454, 546, 648, 722, 789, 823, 875, 899, 904, 945, 1002, 1292, 1350],
    isDead: false
};

let enemies = [];
let bullets = [];
let waves = 0;
let bosses = [];
let bossSpawned = false;

// Keyboard state
let keys = {};

// Handle Key Presses
document.addEventListener('keydown', (e) => {
    keys[e.key] = true;
});

document.addEventListener('keyup', (e) => {
    keys[e.key] = false;
});

document.addEventListener('mousedown', (e) => {
    if (e.button === 0 || e.button === 2) shoot(); // Left and Right mouse buttons
});

document.addEventListener('contextmenu', (e) => e.preventDefault()); // Disable right-click menu

// Create a player spaceship
function drawPlayer() {
    ctx.fillStyle = 'blue';
    ctx.fillRect(player.x, player.y, player.width, player.height);
}

// Create different types of enemies
function createEnemy() {
    if (enemies.length < maxEnemies) {
        let enemyType = Math.floor(Math.random() * 3);
        let enemy = {
            x: canvas.width,
            y: Math.random() * (canvas.height - enemySize),
            width: enemySize,
            height: enemySize,
            health: 10 + (waves * 2),
            damage: 5 + waves,
            type: enemyType
        };

        if (waves >= 23) {
            // Increase enemy health and damage after wave 23
            enemy.health += waves * 2;
            enemy.damage += waves;
        }

        if (enemyType === 1) {
            enemy.color = 'orange'; // Fast enemy
            enemy.speed = enemySpeed + 1;
        } else if (enemyType === 2) {
            enemy.color = 'purple'; // Tank enemy
            enemy.damage += 5;
        } else {
            enemy.color = 'red'; // Regular enemy
        }

        enemies.push(enemy);
    }
}

// Draw enemies
function drawEnemies() {
    enemies.forEach(enemy => {
        ctx.fillStyle = enemy.color;
        ctx.fillRect(enemy.x, enemy.y, enemy.width, enemy.height);
    });
}

// Create a bullet
function shoot() {
    if (player.isDead) return;
    if (bullets.length < maxBullets) {
        let bullet = {
            x: player.x + player.width,
            y: player.y + player.height / 2,
            width: bulletSize,
            height: bulletSize,
            damage: player.level * 2
        };
        bullets.push(bullet);
    }
}

// Draw bullets
function drawBullets() {
    ctx.fillStyle = 'yellow';
    bullets.forEach(bullet => ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height));
}

// Update player movement
function updatePlayer() {
    if (player.isDead) return;

    if (keys['ArrowUp'] || keys['w']) player.y -= playerSpeed;
    if (keys['ArrowDown'] || keys['s']) player.y += playerSpeed;
    if (keys['ArrowLeft'] || keys['a']) player.x -= playerSpeed;
    if (keys['ArrowRight'] || keys['d']) player.x += playerSpeed;

    // Ensure player stays within the canvas bounds
    player.y = Math.max(0, Math.min(canvas.height - player.height, player.y));
    player.x = Math.max(0, Math.min(canvas.width - player.width, player.x));
}

// Update bullets
function updateBullets() {
    bullets.forEach(bullet => bullet.x += bulletSpeed);
    bullets = bullets.filter(bullet => bullet.x < canvas.width);
}

// Update enemies
function updateEnemies() {
    enemies.forEach(enemy => {
        enemy.x -= enemy.speed || enemySpeed;
        if (enemy.x + enemy.width < 0) {
            enemies = enemies.filter(e => e !== enemy);
        }
    });
}

// Create a boss
function createBoss() {
    if (!bossSpawned) {
        let boss = {
            x: canvas.width,
            y: Math.random() * (canvas.height - enemySize * 2),
            width: enemySize * 2,
            height: enemySize * 2,
            health: 100 + waves * 10,
            damage: 10 + waves * 2,
            color: 'green'
        };
        bosses.push(boss);
        bossSpawned = true;
    }
}

// Draw bosses
function drawBosses() {
    bosses.forEach(boss => {
        ctx.fillStyle = boss.color;
        ctx.fillRect(boss.x, boss.y, boss.width, boss.height);
    });
}

// Boss behavior
function bossBehavior() {
    bosses.forEach(boss => {
        boss.x -= enemySpeed / 2; // Boss moves slower
        if (boss.x + boss.width < 0) {
            bosses = bosses.filter(b => b !== boss);
            bossSpawned = false; // Allow new boss to be created
        }
    });
}

// Collision detection
function detectCollisions() {
    bullets.forEach(bullet => {
        enemies.forEach(enemy => {
            if (bullet.x < enemy.x + enemy.width &&
                bullet.x + bullet.width > enemy.x &&
                bullet.y < enemy.y + enemy.height &&
                bullet.y + bullet.height > enemy.y) {
                
                enemy.health -= bullet.damage;
                bullets = bullets.filter(b => b !== bullet);

                if (enemy.health <= 0) {
                    player.score += 100;
                    player.kills++;
                    player.exp += Math.floor(Math.random() * 100);
                    enemies = enemies.filter(e => e !== enemy);
                    if (player.exp >= player.maxExp) levelUp();
                }
            }
        });

        bosses.forEach(boss => {
            if (bullet.x < boss.x + boss.width &&
                bullet.x + bullet.width > boss.x &&
                bullet.y < boss.y + boss.height &&
                bullet.y + bullet.height > boss.y) {
                
                boss.health -= bullet.damage;
                bullets = bullets.filter(b => b !== bullet);

                if (boss.health <= 0) {
                    player.score += 500;
                    player.kills += 5;
                    player.exp += 500;
                    bosses = bosses.filter(b => b !== boss);
                    bossSpawned = false; // Allow new boss to be created
                }
            }
        });
    });

    enemies.forEach(enemy => {
        // Check distance to determine if player should take damage
        const distance = Math.hypot(player.x - enemy.x, player.y - enemy.y);
        if (distance < damageDistance) {
            if (player.x < enemy.x + enemy.width &&
                player.x + player.width > enemy.x &&
                player.y < enemy.y + enemy.height &&
                player.y + player.height > enemy.y) {
                
                // Handle player taking damage only if collision with enemy
                if (!player.isDead) {
                    player.health -= enemy.damage;
                    if (player.health <= 0) {
                        player.isDead = true;
                        setTimeout(() => {
                            location.reload(); // Restart the game
                        }, 1000);
                    }
                }
            }
        }
    });

    bosses.forEach(boss => {
        // Check distance to determine if player should take damage
        const distance = Math.hypot(player.x - boss.x, player.y - boss.y);
        if (distance < damageDistance) {
            if (player.x < boss.x + boss.width &&
                player.x + player.width > boss.x &&
                player.y < boss.y + boss.height &&
                player.y + player.height > boss.y) {
                
                // Handle player taking damage only if collision with boss
                if (!player.isDead) {
                    player.health -= boss.damage;
                    if (player.health <= 0) {
                        player.isDead = true;
                        setTimeout(() => {
                            location.reload(); // Restart the game
                        }, 1000);
                    }
                }
            }
        }
    });
}

// Level up
function levelUp() {
    player.level++;
    player.exp = 0;
    if (player.level < player.levelUpThresholds.length) {
        player.maxExp = player.levelUpThresholds[player.level - 1];
    } else {
        player.maxExp = player.levelUpThresholds[player.levelUpThresholds.length - 1];
    }
    player.lives++;
    waves++;
}

// Draw health bar
function drawHealthBar() {
    ctx.fillStyle = 'red';
    ctx.fillRect(10, canvas.height - 30, 200, 20);
    
    ctx.fillStyle = 'red';
    ctx.fillRect(10, canvas.height - 30, (player.health / player.maxHealth) * 200, 20);
    
    ctx.strokeStyle = 'black';
    ctx.strokeRect(10, canvas.height - 30, 200, 20);
}

// Draw HUD
function drawHUD() {
    ctx.fillStyle = 'white';
    ctx.font = '20px Arial';
    ctx.fillText(`Score: ${player.score}`, 10, 20);
    ctx.fillText(`Kills: ${player.kills}`, 10, 50);
    ctx.fillText(`Level: ${player.level}`, 10, 80);
    ctx.fillText(`EXP: ${player.exp}/${player.maxExp}`, 10, 110);
    
    drawHealthBar();
}

// Game loop
function gameLoop() {
    if (player.isDead) return;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    drawPlayer();
    drawEnemies();
    drawBosses();
    drawBullets();
    drawHUD();
    
    updatePlayer();
    updateBullets();
    updateEnemies();
    bossBehavior();
    detectCollisions();
    
    if (Math.random() < 0.02 && enemies.length < maxEnemies) createEnemy(); // Create enemies randomly
    if (Math.random() < 0.01 && !bossSpawned && player.level > 2) createBoss(); // Create boss occasionally
    
    requestAnimationFrame(gameLoop);
}

gameLoop();
